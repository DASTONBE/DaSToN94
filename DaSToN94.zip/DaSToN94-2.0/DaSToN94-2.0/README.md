# Termux interface Qurxin 

<img src="/f.jpg" >

#### Beautify theme for Termux App With a warm welcome by yahya in 16-octuber-2020

## [+] Installation & Usage
```
apt update
pkg install git python mpv figlet -y
pip install lolcat
git clone https://github.com/fikrado/qurxin
cd qurxin
chmod +x *
sh install.sh
exit
```
### install all in one time
```
apt update && apt install git -y && pkg install mpv figlet python && pip install lolcat && git clone https://github.com/fikrado/qurxin && cd qurxin && chmod +x * && ./install.sh
```
## screen shot

<img src="/s.jpg" >

## How to remove 
```
cd qurxin

bash rvt.sh
```
# thanks for using my script

    
## [+] Find Me on :
##### https://instagram.com/mr__yahye

